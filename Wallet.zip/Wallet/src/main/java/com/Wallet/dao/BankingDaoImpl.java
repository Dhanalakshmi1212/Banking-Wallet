package com.Wallet.dao;

import java.util.HashMap;
import java.util.Optional;

import com.Wallet.bean.Customer;
import com.Wallet.db.BankingDB;
import com.Wallet.exception.BankingException;

public class BankingDaoImpl implements BankingDao{
	static HashMap<Integer, Customer> requestMap=BankingDB.getBankingMap();
	Customer c= new Customer();
	String app=null;
	String sum=null;


	@Override
	public boolean login(int accountNumber, String password) throws BankingException {
		try {
			Customer request=requestMap.get(accountNumber);
			if(request==null) {
				throw new BankingException("Incorrect accountNumber");
			}
			else {
				if(password.equals(request)) {
					throw new BankingException("Incorrect password");
				}
			}
		}catch (Exception e) {
			throw new BankingException(e.getMessage());
		}
		return true;
	}

		@Override
		public int createAccount(String username, String password) throws BankingException {
			try {
			if(requestMap.size()==0) {
				c.setAccountNumber(1001);
			}
			else {
				Optional<Integer> accno=requestMap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int accNumber=accno.get()+1;
				c.setAccountNumber(accNumber);
			}
			requestMap.put(c.getAccountNumber(), c);
			return c.getAccountNumber();
			}catch (Exception e) {
				throw new BankingException(e.getMessage());
				
					}
			}
		
		@Override
		public double depositAmount(int accNo, double amount) throws BankingException {
		Customer c=new Customer();
		try {
			c=requestMap.get(accNo);
			double balance=c.getBalance();
			balance+=amount;
			c.setBalance(balance);
			if(c.getTransaction()==null) {
				c.setTransaction("Account number:"+accNo+"credited with"+amount);
			}
			else {
				app="\nAccount Number:"+accNo+"credited with"+amount;
				sum=c.getTransaction()+app;
				c.setTransaction(sum);
			}
			requestMap.put(accNo, c);
			return c.getBalance();			
			} catch (Exception e) {
			throw new BankingException(e.getMessage());
		}
		}
		
		
		
		
		@Override
		public double getBalance(int accNo) throws BankingException {
			Customer c= new Customer();
			try {
				c=requestMap.get(accNo);
				if(c==null) {
					throw new BankingException ("Invalid Account Number");
				}
				return c.getBalance();
			} catch(Exception e) {
				throw new BankingException(e.getMessage());
			}
			
		}
		
		
		
		@Override
		public double withdrawAmount(int accNo, double amount) throws BankingException {
			Customer c=new Customer();
			try {
				c=requestMap.get(accNo);
				double balance=c.getBalance();
				balance-=amount;
				c.setBalance(balance);
				if(c.getTransaction()==null) {
					c.setTransaction("Account number:"+accNo+"debited with"+amount);
				}
				else {
					app="\nAccount Number:"+accNo+"debited with"+amount;
					sum=c.getTransaction()+app;
					c.setTransaction(sum);
					
				}
				requestMap.put(accNo, c);
				return c.getBalance();			
				} catch (Exception e) {
				throw new BankingException(e.getMessage());
			}
		}
				
				
		
		@Override
		public boolean transferAmount(int accNo, int accNo2, double amount) throws BankingException {
			Customer c=new Customer();
			Customer c1=new Customer();
			try {
				c=requestMap.get(accNo);
				double balance=c.getBalance();
				System.out.println("Initial balance in:"+accNo+" is: "+balance);
				balance-=amount;
				c.setBalance(balance);
				if(c.getTransaction()==null) {
				c.setTransaction("Account number:"+accNo+"has deposited"+amount+"in account"+accNo2);
				} 
				else {
					app="\nAccount number:"+accNo+"has deposited"+amount+"in account"+accNo2;
					sum=c.getTransaction()+app;
					c.setTransaction(sum);
					}
				
				
				c.setTransaction("Account number:"+accNo+"has deposited"+amount+"in account"+accNo2);
				requestMap.put(accNo, c);
				System.out.println("New balance in:"+accNo+"is:"+c.getBalance());
				c1=requestMap.get(accNo2);
				balance=c1.getBalance();
				System.out.println("Initial balance in:"+accNo2+"is:"+balance);
				balance+=amount;
				c1.setBalance(balance);
				if(c1.getTransaction()==null) {
					c.setTransaction("Account number:"+accNo2+"credited with"+amount+"from account"+accNo);
					}
				else {
				app="\nAccount number:"+accNo2+"credited with"+amount+"from account"+accNo;
				sum=c.getTransaction()+app;
				c.setTransaction(sum);
				}
				requestMap.put(accNo2, c1);
				System.out.println("New balance in:"+accNo2+"is:"+c1.getBalance());
				return true;
		} catch (Exception e) {
			throw new BankingException(e.getMessage());
		}
		}

		@Override
		public String printTransaction(int accNo) throws BankingException {
			String str="No transactions";
			Customer c=new Customer();
			try {
				c=requestMap.get(accNo);
				if(c==null) {
					throw new BankingException("Invalid account number");
				}
				if(c.getTransaction()==null) {
					return str;
				}
				else {
					return c.getTransaction();
				}
			}catch (Exception e) {
				throw new BankingException(e.getMessage());
			}
			
		}
}


