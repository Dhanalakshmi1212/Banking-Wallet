package com.Wallet.service;

import com.Wallet.bean.Customer;
import com.Wallet.dao.BankingDao;
import com.Wallet.dao.BankingDaoImpl;
import com.Wallet.exception.BankingException;

public class BankingServiceImpl implements BankingService{
	BankingDao bankingDao= new BankingDaoImpl();
	@Override
	public boolean validateRequest(Customer c) throws BankingException {
		
			if(validateName(c.getCustomerName()) && validatePhone(c.getMobile()) 
					&& validateAadhar(c.getAadharNumber()) && validatePan(c.getPanNumber())) {
				return true;
			}
	
	return false;
	}
				

	private boolean validateName(String customerName) throws BankingException {
		if(customerName.isEmpty()||customerName==null) {
			throw new BankingException("Customer Name cannot be empty");
		}
		else {
			if(!customerName.matches("[A-Z][A-Za-z]{2,}")) {
				throw new BankingException
				("Customer name should start with capital letter and should be of 3 alphabets");
				}
		}
		return true;
	}
		

	private boolean validatePan(String panNumber) throws BankingException {
		if(panNumber.isEmpty()|| panNumber==null) {
			throw new BankingException("pan Number should not be empty");
		}
		else {
			if(!panNumber.matches("[A-Z]{5}\\d{4}[A-Z]")) {
				throw new BankingException ("pan Number is not valid");
			}
		}
		return true;
	}

	private boolean validatePhone(String mobile) throws BankingException {
		if(mobile.isEmpty()|| mobile==null) {
			throw new BankingException("Phone number should not be empty");
			}
		else {
			if(!mobile.matches("\\d{10}")) {
				throw new BankingException("Phone number should be 10 digits");
			}
		}
		return true;
	}

	private boolean validateAadhar(String aadharNumber) throws BankingException {
		if(aadharNumber.isEmpty()|| aadharNumber==null) {
			throw new BankingException("Aadhar Number should not be empty");
		}
		else {
			if(!aadharNumber.matches("\\d{12}")) {
				throw new BankingException("Aadhar Number should be 12 digits");
			}
		}
		return true;
				}


	

	@Override
	public boolean login(int accountNumber, String password) throws BankingException {
		
		return bankingDao.login(accountNumber, password);
	}


	@Override
	public int createAccount(String username, String password) throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.createAccount(username, password);
	}


	@Override
	public double getBalance(int accNo) throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.getBalance(accNo);
	}


	@Override
	public double depositAmount(int accNo, double amount) throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.depositAmount(accNo, amount);
	}


	@Override
	public double withdrawAmount(int accNo, double amount) throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.withdrawAmount(accNo, amount);
	}


	@Override
	public boolean transferAmount(int accNo, int accNo2, double amount) throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.transferAmount(accNo, accNo2, amount);
	}


	@Override
	public String printTransaction(int accNo) throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.printTransaction(accNo);
	}
		
	}



