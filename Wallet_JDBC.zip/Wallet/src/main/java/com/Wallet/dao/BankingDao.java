package com.Wallet.dao;

import com.Wallet.bean.Customer;
import com.Wallet.exception.BankingException;

public interface BankingDao {
	boolean login(int accountNumber,String password) throws BankingException;
	public int createAccount(Customer customerRequest) throws BankingException;
	double getBalance(int accNo) throws BankingException;
	boolean depositAmount(int accNo, double amount) throws BankingException;
	boolean withdrawAmount(int accNo, double amount) throws BankingException;
	boolean transferAmount(int accNo, int accNo2, double amount) throws BankingException;
	boolean printTransaction(int accNo) throws BankingException;
}