package com.Wallet.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.Wallet.bean.Customer;
import com.Wallet.exception.BankingException;
import com.Wallet.service.BankingService;
import com.Wallet.service.BankingServiceImpl;


public class BankingDaoImplTest {
BankingService bs;
	
	@Before
	public void setup() {
		bs= new BankingServiceImpl();
	}
	
	@After
	public void teardown() {
		bs=null;
	}

	@Test
	public void testLogin() {
		try {
			assertEquals(bs.login(1002, "rangan"), true);
		} catch (BankingException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testCreateAccount() {
		try {
			Customer cust = new Customer();
			cust.setCustomerName("dhana");
			cust.setMobile("9003209877");
			cust.setMailId("dhana@gmail.com");
			assertNotEquals(bs.createAccount(cust),22);
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	public void testDepositAmount() {
		try {
			assertEquals(bs.depositAmount(1, 1000),true);
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Test
	public void testGetBalance() {
	try {
		assertEquals(bs.getBalance(1001), 25000, 0.0);
	}catch (BankingException e) {
		e.printStackTrace();
	}
	}

	@Test
	public void testWithdrawAmount() {
		try {
			assertEquals(bs.withdrawAmount(1, 1000),true);
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Test
	public void testTransferAmount() {
		try {
			assertEquals(bs.transferAmount(1,2,1),true);
			assertEquals(bs.transferAmount(2,1,1),true);
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testPrintTransaction() {
		try {
			assertEquals(bs.printTransaction(1),false);
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}



