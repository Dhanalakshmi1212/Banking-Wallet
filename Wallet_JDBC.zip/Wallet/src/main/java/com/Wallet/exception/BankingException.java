package com.Wallet.exception;

public class BankingException extends Exception {
	private static final long serialVersionUID = 726264577455921591L;
	public BankingException() {
		super();
	}
	public BankingException(String message) {
	super (message);

}

}
