package com.Wallet;


import java.util.Collection;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.Wallet.bean.Customer;
import com.Wallet.exception.BankingException;
import com.Wallet.service.BankingService;
import com.Wallet.service.BankingServiceImpl;


/**
 * Author: Dhanalakshmi.P
 * 
 *
 */
public class App 
{
	Scanner sc= new Scanner(System.in);
	BankingService bankingService=new BankingServiceImpl();
	static Logger logger = Logger.getRootLogger();
	
    public static void main( String[] args )
    {
    	PropertyConfigurator.configure("resources//log4j.properties");
    	App a= new App();
    	String option=null;
    	String choice=null;
    	boolean menu=true;
    	boolean checkuser=false;
    	while(true) {
        System.out.println( "========Payment Wallet Application=========");
        System.out.println("1. Create Account");
        System.out.println("2. Already have an account");
        System.out.println("3. Exit");
        System.out.println("Choose an option");
        option=a.sc.nextLine();
        
        switch(option) {
		case "1":
			a.createAccount();
			break;
		case "2": System.out.println("Enter account number:");
		int accNo=Integer.parseInt(a.sc.nextLine());
		menu=a.login(accNo);
		while(menu) {
			System.out.println("1 Show Balance");
			System.out.println("2. Deposit");
			System.out.println("3. Withdraw");
			System.out.println("4. Fund Transfer");
			System.out.println("5. Print Transaction");
			System.out.println("6. Back");
			System.out.println("Enter your choice");
			 choice=a.sc.nextLine();
			switch(choice) {
			case "1":
				a.displayBalance(accNo);
				break;
			case "2":
				a.deposit(accNo);
				break;
			case "3":
				a.withDraw(accNo);
				break;
			case "4":
				a.transfer(accNo);
				break;
			case "5":
				a.printTransaction(accNo);
				
				break;
			case "6":
				menu=false;
				System.out.println();
				break;
				default:
					System.out.println("Please enter a option between 1 and 6");
					break;
			}
		} 
		break;
		case "3": System.exit(0);
		break;
		default: System.out.println("Invalid option");
		break;
        }
    	}
    }
			
		private void printTransaction(int accNo) {
			try {
				boolean transaction=bankingService.printTransaction(accNo);
				System.out.println("Transaction:"+transaction);
			} catch (BankingException e) {
				System.out.println();
	    		System.err.println(e.getMessage());
	    		System.out.println();
	    	}
	    	catch (Exception e) {
	    		System.out.println();
	    		System.err.println(e.getMessage());
	    		System.out.println();
	    	}	
			}
	
		
	

		private void transfer(int accNo) {
			try {
				System.out.println("Enter account number to which you want to transfer:");
				int accNo2=Integer.parseInt(sc.nextLine());
				System.out.println("Enter amount to be transferred:");
				double amount=Double.parseDouble(sc.nextLine());
				boolean result=bankingService.transferAmount(accNo,accNo2, amount);
				if(result) {
					System.out.println("Transaction complete");
				}
			} catch (BankingException e) {
				System.out.println();
	    		System.err.println(e.getMessage());
	    		System.out.println();
	    	}
	    	catch (Exception e) {
	    		System.out.println();
	    		System.err.println(e.getMessage());
	    		System.out.println();
	    	}	
			}
				
		
		private void withDraw(int accNo) {
			try {
				System.out.println("Enter amount has to be withdraw:");
				double amount=Double.parseDouble(sc.nextLine());
				boolean balance=bankingService.withdrawAmount(accNo, amount);
				System.out.println();
				System.out.println("Account number:" +accNo);
				System.out.println("Balance:" +balance);
				System.out.println();
			} catch (BankingException e) {
				System.out.println();
	    		System.err.println(e.getMessage());
	    		System.out.println();
	    	}
	    	catch (Exception e) {
	    		System.out.println();
	    		System.err.println(e.getMessage());
	    		System.out.println();
	    	}	
				
			}
		
		private void deposit(int accNo) {
			try {
				System.out.println("Enter deposit amount");
				double amount=Double.parseDouble(sc.nextLine());
				boolean  balance=bankingService.depositAmount(accNo, amount);
				System.out.println();
				System.out.println("Account number:" +accNo);
				System.out.println("Balance:" +balance);
				System.out.println();
			} catch (BankingException e) {
				System.out.println();
	    		System.err.println("An error occured"+e.getMessage());
	    		System.out.println();
	    	}
	    	catch (Exception e) {
	    		System.out.println();
	    		System.err.println("An error occured"+e.getMessage());
	    		System.out.println();
	    	}	
				
			}
		
		private boolean login(int accNo) {
			boolean result =false;
			try {
				System.out.println("Enter password");
				String pass=sc.nextLine();
				result=bankingService.login(accNo, pass);
				return result;
				}  catch (BankingException e) {
					System.out.println();
		    		System.err.println("An error occured"+e.getMessage());
		    		System.out.println();
		    	}
			catch (Exception e) {
	    		System.out.println();
	    		System.err.println("An error occured"+e.getMessage());
	    		System.out.println();
	    	}
			
		return result; 
		}
    	
    	private void displayBalance(int accountNumber) {
    		double balance;
    		try {
    			balance=bankingService.getBalance(accountNumber);
    			System.out.println();
				System.out.println("Account number:" +accountNumber);
				System.out.println("Balance:" +balance);
				System.out.println();
			} catch (BankingException e) {
				System.out.println();
	    		System.err.println("An error occured"+e.getMessage());
	    		System.out.println();
	    	}
	    	catch (Exception e) {
	    		System.out.println();
	    
	   System.err.println("An error occured"+e.getMessage());
	    		System.out.println();
	    	}	
				
			}
    	
    	private void createAccount() {
    		Customer c= new Customer();
        	System.out.println("Enter customerName");
        	try {
        	c.setCustomerName(sc.nextLine());
        	System.out.println("Enter mobile");
    		c.setMobile(sc.nextLine());
    		System.out.println("Enter Email");
    		c.setMailId(sc.nextLine());
    		System.out.println("Enter the panNumber");
    		c.setPanNumber(sc.nextLine());
    		System.out.println("Enter the address");
    		c.setAddress(sc.nextLine());
    		System.out.println("Enter the aadharNumber");
    		c.setAadharNumber(sc.nextLine());
    		System.out.println("Enter the password");
    		c.setPassword(sc.nextLine());
    		
    		boolean result=bankingService.validate(c);
    		if(result) {
    			int id=bankingService.createAccount(c);
    			System.out.println("Dear"+c.getCustomerName()+"account created successfully with account number:"+id);
  }
    	} catch (BankingException e) {
			System.out.println();
    		System.err.println("An error occured"+e.getMessage());
    		System.out.println();
    	}
    	catch (Exception e) {
    		System.out.println();
    		System.err.println("An error occured"+e.getMessage());
    		System.out.println();
    	}	
			
		}
			
}

   