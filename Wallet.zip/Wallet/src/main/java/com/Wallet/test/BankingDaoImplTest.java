package com.Wallet.test;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.Wallet.exception.BankingException;
import com.Wallet.service.BankingService;
import com.Wallet.service.BankingServiceImpl;

public class BankingDaoImplTest {
BankingService bs;
	
	@Before
	public void setup() {
		bs= new BankingServiceImpl();
	}
	
	@After
	public void teardown() {
		bs=null;
	}

	@Test
	public void testLogin() {
		try {
			assertEquals(bs.login(1002, "rangan"), true);
		} catch (BankingException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testCreateAccount() {
		try {
			assertEquals(bs.createAccount("Poori", "dhana"),1003);
		}catch (BankingException e) {
			e.printStackTrace();
		}
		}

	@Test
	public void testDepositAmount() {
		try {
		assertEquals(bs.depositAmount(1002, 1000),57000,0.0);
	} catch (BankingException e) {
		e.printStackTrace();
	}
}

	@Test
	public void testGetBalance() {
	try {
		assertEquals(bs.getBalance(1001), 25000, 0.0);
	}catch (BankingException e) {
		e.printStackTrace();
	}
	}

	@Test
	public void testWithdrawAmount() {
try {
	assertEquals(bs.withdrawAmount(1001, 2000), 23000, 0.0);
} catch (BankingException e) {
	e.printStackTrace();
}
	}

	@Test
	public void testTransferAmount() {
	try {
			assertEquals(bs.transferAmount(1002, 1001, 0), true);
		} catch (BankingException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testPrintTransaction() {
		try {
			assertEquals(bs.printTransaction(1001),"No transactions");
		} catch (BankingException e) {
			e.printStackTrace();
		}
	}

}



