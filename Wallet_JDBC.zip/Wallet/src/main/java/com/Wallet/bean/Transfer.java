package com.Wallet.bean;

import java.sql.Date;

public class Transfer {

	private int transid;
	private String transfertype;
	private Date transDate;
	private double amount;
	
	public Transfer(int transid, String transfertype, Date transDate, double amount, long accountno) {
		super();
		this.transid = transid;
		this.transfertype = transfertype;
		this.transDate = transDate;
		this.amount = amount;
		this.accountno = accountno;
	}
	public Transfer() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Transfer [transid=" + transid + ", transfertype=" + transfertype + ", transDate=" + transDate
				+ ", amount=" + amount + ", accountno=" + accountno + "]";
	}

	private long accountno;

	public int getTransid() {
		return transid;
	}

	public void setTransid(int transid) {
		this.transid = transid;
	}

	public String getTransfertype() {
		return transfertype;
	}

	public void setTransfertype(String transfertype) {
		this.transfertype = transfertype;
	}

	public Date getTransDate() {
		return transDate;
	}

	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public long getAccountno() {
		return accountno;
	}

	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}
	
}
