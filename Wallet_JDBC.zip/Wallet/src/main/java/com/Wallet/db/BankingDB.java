package com.Wallet.db;

import java.util.HashMap;

import com.Wallet.bean.Customer;

public class BankingDB {
	private static HashMap<Integer,Customer>
	BankingMap=new HashMap<Integer,Customer>();

		public static HashMap<Integer, Customer> getBankingMap() {
			return BankingMap;
		}
		static {
			BankingMap.put(1001, new Customer("Dhana",1001,"9003409822","dhana@gamil.com","ABCDE1234A","Chennai","143256843217",25000,"akaiyaaa",null));
			BankingMap.put(1002, new Customer("Priya",1001,"9003289022","priya@gamil.com","FGHIJ1234A","Chennai","984378219854",56000,"rangan",null));
		}

}
