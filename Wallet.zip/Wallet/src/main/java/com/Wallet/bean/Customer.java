package com.Wallet.bean;

public class Customer {

	private String customerName;
	private int accountNumber;
	private String mobile;
	private String mailId;
	private String panNumber;
	private String address;
	private String aadharNumber;
	private double balance;
	private String password;
	private String transaction;
	public String getTransaction() {
		return transaction;
	}
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAadharNumber() {
		return aadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}
	public Customer(String customerName, int accountNumber, String mobile, String mailId, String panNumber,
			String address, String aadharNumber, double balance, String password, String transaction) {
		super();
		this.customerName = customerName;
		this.accountNumber = accountNumber;
		this.mobile = mobile;
		this.mailId = mailId;
		this.panNumber = panNumber;
		this.address = address;
		this.aadharNumber = aadharNumber;
		this.balance = balance;
		this.password = password;
		this.transaction=transaction;
	}
	public Customer() {
		customerName=null;
		accountNumber=0;
		mobile=null;
		mailId=null;
		panNumber=null;
		address=null;
		aadharNumber=null;
		balance=0.0;
		password=null;
		transaction=null;
	}
	
}
